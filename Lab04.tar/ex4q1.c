#include <stdio.h>
#include <stdlib.h>
/* Author Melrita Cyriac


source: https://www.youtube.com/watch?v=CzAgM5bez-g&ab_channel=PortfolioCourses
*/



int main(){

char str1[1000000];
scanf("%s",str1);

int i= 0;

int damaged_crop[4]={0,0,0,0}; //CTPL
int sold_crop[4]={0,0,0,0}; //CTPL


while((str1[i]!='\0'))
{

if (str1[i]=='#'){
i++;
if (str1[i]=='P'){
//printf("%c%d yes" ,str1[i],damaged_crop[i]);
damaged_crop[2]=damaged_crop[2]+1;
i++;
}//if statement p

if (str1[i]=='C'){
damaged_crop[0]=damaged_crop[0]+1;
i++;
} //if statement c

if (str1[i]=='T'){
damaged_crop[1]=damaged_crop[1]+1;
i++;
} //if statement T

if (str1[i]=='L'){
damaged_crop[3]=damaged_crop[3]+1;
i++;
} //if statement L

}//if statement # 


if (str1[i]=='/'){
i++;
//printf("%c" ,str1[i]);
if (str1[i]=='P'){
sold_crop[2]=sold_crop[2]+1;
i++;
}//if statement p

if (str1[i]=='C'){
sold_crop[0]=sold_crop[0]+1;
i++;
} //if statement c

if (str1[i]=='T'){
sold_crop[1]=sold_crop[1]+1;
i++;
} //if statement T

if (str1[i]=='L'){
sold_crop[3]=sold_crop[3]+1;
i++;
} //if statement L

}//if statement /

} // for loop

float total_c=damaged_crop[0]+sold_crop[0];
float total_t=damaged_crop[1]+sold_crop[1];
float total_p=damaged_crop[2]+sold_crop[2];
float total_l=damaged_crop[3]+sold_crop[3];

float net_profit = (sold_crop[0]*0.50)+(sold_crop[1]*1.25)+(sold_crop[2]*3.00)+(sold_crop[3]*1.00)-(total_c*0.05)-(total_t*0.25)-(total_p*0.70)-(total_l*0.30);

if (net_profit<0){
net_profit=net_profit*(-1);
printf("Net profit: -$%.2f\n",net_profit);
}
else {
printf("Net profit: $%.2f\n",net_profit);
}

return 0;

}

