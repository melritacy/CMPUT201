#include <stdio.h>
#include <stdlib.h>
/* Author Melrita Cyriac

https://www.tutorialspoint.com/c_standard_library/c_function_qsort.htm
https://www.programiz.com/dsa/binary-search
*/

int compare(const void*a, const void*b){

return( *(int*)a-*(int*)b);

}


int binarysearch(float array[],float x, int low , int high)

{
while (low <= high) {
int mid = low + (high-low)/2;

if (array[mid]<=x)
{
if(mid==high||array[mid+1]>x){
return mid;
}//inner if

else {//searching right half
low = mid+1;
}
}//outer if

else{
high = mid - 1;
}

}// while loop bracket

return -1;
}

int main(){

char number_boxes[100000] ; float trucks_array[1000000]; float  boxes[2000]; 

int i=0;
scanf("%s",number_boxes);
int boxes_number = atoi(number_boxes);
//printf("%d",boxes_number);

while(i<boxes_number)
{
scanf("%f",&boxes[i]);
i++;
}//while 

float copied_boxes[i];
int m = 0;

while(boxes[m]!=0)
{
copied_boxes[m]=boxes[m];
m++;
}//while


int j=0;
while(scanf("%f",&trucks_array[j])==1){
j++;
}//while 

float copied_trucks_array[j];



int k =0;
while(trucks_array[k]!=0)
{
copied_trucks_array[k]=trucks_array[k];
k++;}//while


qsort(copied_boxes,i,sizeof(int),compare);
qsort(copied_trucks_array,j,sizeof(int),compare);


int l =0;
 
while(l<=j && trucks_array[l]!=0)
{
float sum = 0;
int sum_count=0;
int n=0;
int val=binarysearch(copied_boxes,trucks_array[l],0,i-1); 


for (n=0;n<=val;n++){
sum += copied_boxes[n];
sum_count++;

if (sum==trucks_array[l])
{
printf("%d\n",sum_count);
break;
}//if part 1

if (sum>trucks_array[l])
{
printf("%d\n",sum_count-1);
break;
}
if (sum<trucks_array[l]&&n==val)
{
printf("%d\n",sum_count);
break;

}

}//for loop

l++;
} //while

} //main





