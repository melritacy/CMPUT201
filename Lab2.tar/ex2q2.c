#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(){
        int cad,result;
        printf("Enter CAD amount : ");
        scanf("%d",&cad);
        if( cad> 100000 || cad < 0)
        {
        exit(100);
        }
        double usd =(cad *0.75);
        result = round(usd);
        printf("Converted USD amount : %d\n",result);
        int hundreds,fifties,twenties,tens,fives,twos;
        hundreds = result/100;
        int result1 = result%100;
        fifties = result1/50;
        int result2 = result1%50;
        twenties = result2/20;
        int result3 = result2%20;
        tens = result3/10;
        int result4 = result3%10;
        fives = result4/5;
        int result5 =result%5;
        twos = result5/2;
        int result6 = result5%2;
        printf("$100 bills :%d\n",hundreds);
        printf(" $50 bills :%d\n",fifties);
        printf(" $20 bills :%d\n",twenties);
        printf(" $10 bills :%d\n",tens);
        printf("  $5 bills :%d\n",fives);
        printf("  $2 bills :%d\n",twos);
        printf("  $1 bills :%d\n",result6);
        return 0;

}


