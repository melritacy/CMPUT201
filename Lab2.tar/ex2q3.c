#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(){
	int hardcover , softcover ,ebooks;
	printf("How many hardcover books are you buying? ");
	scanf("%d",&hardcover);
	printf("How many softcover books are you buying? ");
	scanf("%d",&softcover);
        printf("How many ebooks are you buying? ");
	scanf("%d",&ebooks);

	int initial_val;
	if (hardcover>1000000||hardcover<0||softcover>1000000||softcover<0||ebooks>1000000||ebooks<0)
	{
		exit(100);
	}
	initial_val =(15*hardcover)+(12*softcover)+(7*ebooks);
	if(hardcover>=2)
	{
		initial_val = initial_val -5;
	}
	if(softcover>=4)
        {
        	initial_val = initial_val -10;
        }
	if(softcover+hardcover>=6)
        {
        	initial_val = initial_val -20;
        }


	float percentage=100;
	if (hardcover>=1 && softcover>=1 && ebooks>=1)
        {
        	percentage = percentage -3;
        }	
	if( ebooks>=3)
        {
        	percentage = percentage -4;
        }
	if(initial_val>75)
        {
       		percentage = percentage -10;
        }
	if(initial_val>150)
        {
       		percentage = percentage -15;
        }
	
	float final_val;
	percentage= percentage/100;
	final_val = initial_val*percentage;

	printf("Order Total: $%.2f\n",final_val);

	return 0;
}


