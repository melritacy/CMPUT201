#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int* head;
    int* start;
    int* end;
    int length;
    int capacity;
} Ring;

Ring* initRing(int capacity) {
    Ring* ring = (Ring*)malloc(sizeof(Ring));
    ring->head = (int*)malloc(capacity * sizeof(int));
    ring->start = ring->head;
    ring->end = ring->head;
    ring->length = 0;
    ring->capacity = capacity;
    return ring;
}

void push_back(Ring* ring, int value, char student_type) {
    if (ring->length == ring->capacity) {
        int newCapacity = ring->capacity * 2;
        int* newHead = (int*)malloc(newCapacity * sizeof(int));

        int* newStart = newHead + (ring->start - ring->head); ;
        int* newEnd = newStart + ring->length;;
        for (int* i = ring->start; i < ring->end; ++i) {
            *newEnd++ = *i;
        }
        free(ring->head);
    
        ring->head = newHead;
        ring->start = newStart;
        ring->end = newHead;
        ring->capacity = newCapacity;
        ring->length = newEnd - newStart;
    }

    // Check student type and add the value accordingly
    if (student_type == 'C' && ring->length!=0) {
    if ((ring -> length)%2==0 && ring->length!=0){
        int* middle = ring->head + (ring->length / 2);
        for (int* i = ring->end; i > middle; --i) {
            *i = *(i - 1);
        }
        *middle = value;
        ring->end++;     
    }
    if ((ring -> length)%2!=0 &&ring->length!=0){
        int* middle = ring->head + ((ring->length+1) / 2);
        for (int* i = ring->end; i > middle; --i) {
            *i = *(i - 1);
        }
        *middle = value;
        ring->end++;
    }
       
    } else {
        // Add the value at the end of the ring buffer
        *(ring->end) = value;
        ring->end++;

        if (ring->end == ring->head + ring->capacity) {
            ring->end = ring->head;
        }

    }
    ring->length++;
}

void push_front(Ring* ring) {
    if (ring->length > 0) {
        printf("%d\n", *(ring->start));

        ring->start++;

        if (ring->start == ring->head + ring->capacity) {
            ring->start = ring->head;
        }
        ring->length--;
    } 
    
    else {
       printf("empty\n");
    }
}


void popBack(Ring* ring) {
    if (ring->length > 0) {
        ring->end--;

        // Wrap around if the end pointer reaches the beginning of the buffer
        if (ring->end == ring->head - 1) {
            ring->end = ring->head + ring->capacity - 1;
        }

        ring->length--;
    }
}

int main() {
    Ring* frontRing = initRing(8);
    Ring* backRing = initRing(8);

    char action;
    int x, student_id;

    while (scanf(" %c", &action) == 1) {
        switch (action) {
            case 'N':
                scanf("%d %d", &x, &student_id);
                if (frontRing->length + backRing->length<x) {
                    push_back(frontRing, student_id,action);
                }
                break;
            case 'C':
                scanf("%d %d", &x, &student_id);
                if (frontRing->length > x) {
                    break;
                }
                else if (((frontRing->length + backRing->length)/2) < x) {
                    push_back(frontRing, student_id,action);
                }
                break;
            case 'F':
                if (frontRing->length > 0) {
                    push_front(frontRing);
                } else if (backRing->length > 0) {
                    push_front(backRing);
                } else {
                    printf("empty\n");
                }
                break;
            case 'L':
                if (backRing->length > 0) {
                    popBack(backRing);
                } else if (frontRing->length > 0) {
                    popBack(frontRing);
                } else {
                    printf("empty\n");
                }
                break;
            default:
                // Ignore invalid actions
                break;
        }
    }

    // Free allocated memory
    free(frontRing-> head);
    free(backRing -> head);
    free(frontRing);
    free(backRing);

    return 0;
}


